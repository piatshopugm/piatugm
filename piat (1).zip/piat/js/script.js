document.addEventListener("DOMContentLoaded", function () {
  // Inisialisasi ikon Lucide
  lucide.createIcons();

  // Logika untuk Menu Mobile (Hamburger)
  const mobileMenuButton = document.getElementById("mobile-menu-button");
  const mobileMenu = document.getElementById("mobile-menu");
  mobileMenuButton.addEventListener("click", () => {
    mobileMenu.classList.toggle("hidden");
  });

  // Menutup menu mobile setelah link diklik
  const mobileLinks = mobileMenu.querySelectorAll("a");
  mobileLinks.forEach((link) => {
    link.addEventListener("click", () => {
      mobileMenu.classList.add("hidden");
    });
  });

  // Logika untuk menandai Nav Link yang aktif saat scroll
  const sections = document.querySelectorAll("section");
  const navLinks = document.querySelectorAll("nav a");

  const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.5, // 50% section terlihat
  };

  const sectionObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute("id");
        navLinks.forEach((link) => {
          link.classList.remove("nav-link-active");
          if (link.getAttribute("href") === `#${id}`) {
            link.classList.add("nav-link-active");
          }
        });
      }
    });
  }, observerOptions);

  sections.forEach((section) => {
    sectionObserver.observe(section);
  });

  // Logika untuk animasi fade-in saat scroll
  const animatedElements = document.querySelectorAll(".scroll-animate");
  const animateObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target); // Animasi hanya sekali
        }
      });
    },
    { threshold: 0.1 }
  );

  animatedElements.forEach((el) => {
    animateObserver.observe(el);
  });
});
